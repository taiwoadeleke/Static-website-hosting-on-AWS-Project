Required website URLs

1. Cloudfront domain name

https://d2aoxkv0hlw7k0.cloudfront.net/

2. static website endpoint

http://my-485216630087-bucket.s3-website-us-east-1.amazonaws.com

3. S3 Object url

https://my-485216630087-bucket.s3.amazonaws.com/index.html